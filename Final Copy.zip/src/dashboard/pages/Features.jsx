import React, { useState, useEffect } from 'react';
import { getFeaturesData } from '../../api/dashboardApi';
import { IconLoader2, IconArrowUp, IconArrowDown } from '@tabler/icons-react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';

const Features = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try { setData(await getFeaturesData()); }
      catch (e) { console.error(e); }
      finally { setLoading(false); }
    })();
  }, []);

  if (loading || !data) return (
    <div className="content loading-skeleton">
      <IconLoader2 size={40} /><p>Loading Features Data...</p>
    </div>
  );

  return (
    <div className="content">
      {/* ── Page Header ── */}
      <div>
        <div className="section-label">Features Overview</div>
        <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginTop: '4px' }}>
          Monitor feature adoption rates and customer engagement trends
        </p>
      </div>

      {/* ── KPIs ── */}
      <div className="kpi-row">
        {data.kpis.map((kpi, idx) => (
          <div className="kpi-card" key={idx}>
            <div className="kpi-label">{kpi.label}</div>
            <div className="kpi-value" style={{ fontFamily: 'var(--font-display)' }}>{kpi.value}</div>
            <div className={`kpi-delta ${kpi.trend === 'up' ? 'delta-up' : kpi.trend === 'dn' ? 'delta-dn' : ''}`}
              style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              {kpi.trend === 'up' && <IconArrowUp size={12} />}
              {kpi.trend === 'dn' && <IconArrowDown size={12} />}
              {kpi.delta}
            </div>
          </div>
        ))}
      </div>

      <div className="two-col">
        {/* ── Feature Adoption Trend Chart ── */}
        <div className="card">
          <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>Top Features Adoption Trend</div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data.adoptionTrend || []} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="4 4" vertical={false} stroke="var(--color-border-primary)" />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: 'var(--color-text-muted)', fontFamily: 'var(--font-sans)' }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 12, fill: 'var(--color-text-muted)', fontFamily: 'var(--font-sans)' }} tickLine={false} axisLine={false} tickFormatter={(v) => `${v}%`} domain={[0, 100]} />
              <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 30px rgba(0,0,0,0.08)', fontFamily: 'var(--font-sans)' }} formatter={(val) => [`${val}%`, '']} />
              <Legend iconType="circle" wrapperStyle={{ fontFamily: 'var(--font-sans)', fontSize: '13px' }} />
              <Line type="monotone" dataKey="email" name="Email" stroke="#FF1300" strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 5 }} />
              <Line type="monotone" dataKey="forms" name="Forms" stroke="#530f00" strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 5 }} />
              <Line type="monotone" dataKey="sms" name="SMS" stroke="#fd6533" strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 5 }} />
              <Line type="monotone" dataKey="whatsapp" name="WhatsApp" stroke="#8c2800" strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* ── Current Adoption Bars ── */}
        <div className="card">
          <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>Current Feature Adoption</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', marginTop: '16px' }}>
            {data.features.map((f, idx) => (
              <div key={idx} className="feat-row">
                <div className="feat-name">{f.name}</div>
                <div className="feat-bar-wrap">
                  <div className="feat-bar-fill" style={{ width: `${f.percentage}%`, background: f.color }} />
                </div>
                <div style={{ width: '80px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '12px', color: 'var(--color-text-muted)' }}>{f.users} users</span>
                  <span className="feat-pct" style={{ width: 'auto' }}>{f.percentage}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Features;
