import React, { useState, useEffect } from 'react';
import { getRevenueData } from '../../api/dashboardApi';
import { IconLoader2, IconArrowUp } from '@tabler/icons-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';

const Revenue = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try { setData(await getRevenueData()); }
      catch (e) { console.error(e); }
      finally { setLoading(false); }
    })();
  }, []);

  if (loading || !data) return (
    <div className="content loading-skeleton">
      <IconLoader2 size={40} /><p>Loading Revenue Data...</p>
    </div>
  );

  return (
    <div className="content">
      {/* ── Header ── */}
      <div>
        <div className="section-label">Revenue Overview</div>
        <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginTop: '4px' }}>
          Monthly revenue performance across direct and partner channels
        </p>
      </div>

      {/* ── KPI Cards ── */}
      <div className="kpi-row">
        {data.kpis.map((kpi, idx) => (
          <div className="kpi-card" key={idx}>
            <div className="kpi-label">{kpi.label}</div>
            <div className="kpi-value" style={{ fontFamily: 'var(--font-display)' }}>{kpi.value}</div>
            <div className={`kpi-delta ${kpi.trend === 'up' ? 'delta-up' : kpi.trend === 'dn' ? 'delta-dn' : ''}`}
              style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              {kpi.trend === 'up' && <IconArrowUp size={12} />}
              {kpi.delta}
            </div>
          </div>
        ))}
      </div>

      {/* ── Charts Row ── */}
      <div className="two-col">
        {/* Stacked Bar */}
        <div className="card">
          <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>Monthly Revenue Breakdown</div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data.monthlyRevenue} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="4 4" vertical={false} stroke="var(--color-border-primary)" />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: 'var(--color-text-muted)', fontFamily: 'var(--font-sans)' }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 12, fill: 'var(--color-text-muted)', fontFamily: 'var(--font-sans)' }} tickLine={false} axisLine={false} tickFormatter={(v) => `$${v}K`} />
              <Tooltip cursor={{ fill: 'var(--color-background-secondary)' }} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 30px rgba(0,0,0,0.08)', fontFamily: 'var(--font-sans)' }} />
              <Legend iconType="circle" wrapperStyle={{ fontFamily: 'var(--font-sans)', fontSize: '13px' }} />
              <Bar dataKey="direct" name="Direct Revenue" stackId="a" fill="#FF1300" radius={[0, 0, 5, 5]} />
              <Bar dataKey="partner" name="Partner Revenue" stackId="a" fill="#530f00" radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Revenue By Plan Donut */}
        <div className="card">
          <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>Revenue by Plan Tier</div>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={data.revenueByPlan} cx="50%" cy="50%" innerRadius={75} outerRadius={115} paddingAngle={5} dataKey="value">
                {data.revenueByPlan.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
              </Pie>
              <Tooltip formatter={(val) => `$${val}K`} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 30px rgba(0,0,0,0.08)', fontFamily: 'var(--font-sans)' }} />
              <Legend iconType="circle" wrapperStyle={{ fontFamily: 'var(--font-sans)', fontSize: '13px' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ── Drilldown Table ── */}
      <div className="card">
        <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>
          Revenue Drilldown
          <span style={{ fontSize: '12px', fontWeight: 500, color: 'var(--color-text-muted)' }}>Region → Partner → Plan → Feature</span>
        </div>
        <div style={{ border: '1px solid var(--color-border-primary)', borderRadius: 'var(--border-radius-md)', overflow: 'hidden' }}>
          {data.drilldown.map((row, i) => (
            <div key={i} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: `12px 20px 12px ${20 + row.indent}px`,
              borderBottom: i < data.drilldown.length - 1 ? '1px dashed var(--color-border-primary)' : 'none',
              background: row.indent === 0 ? 'var(--color-background-secondary)' : 'transparent',
              fontSize: row.indent === 0 ? '15px' : '13px',
              fontWeight: row.bold ? 700 : row.indent === 0 ? 700 : 500,
              color: row.indent === 0 ? 'var(--color-text-primary)' : 'var(--color-text-secondary)'
            }}>
              <span>{row.text}</span>
              <span style={{ fontWeight: 700, color: row.bold ? 'var(--color-text-primary)' : 'var(--color-text-muted)' }}>
                {row.value}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Revenue;
