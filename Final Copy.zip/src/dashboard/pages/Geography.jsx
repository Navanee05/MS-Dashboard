import React, { useState, useEffect } from 'react';
import { getGeographyData } from '../../api/dashboardApi';
import { IconLoader2, IconArrowUp, IconArrowDown } from '@tabler/icons-react';
import {
  PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, XAxis, YAxis, CartesianGrid
} from 'recharts';

const Geography = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try { setData(await getGeographyData()); }
      catch (e) { console.error(e); }
      finally { setLoading(false); }
    })();
  }, []);

  if (loading || !data) return (
    <div className="content loading-skeleton">
      <IconLoader2 size={40} /><p>Loading Geography Data...</p>
    </div>
  );

  return (
    <div className="content">
      {/* ── Page Header ── */}
      <div>
        <div className="section-label">Geography Overview</div>
        <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginTop: '4px' }}>
          Regional customer distribution and revenue performance
        </p>
      </div>

      {/* ── KPIs ── */}
      <div className="kpi-row">
        {data.kpis.map((kpi, idx) => (
          <div className="kpi-card" key={idx}>
            <div className="kpi-label">{kpi.label}</div>
            <div className="kpi-value" style={{ fontFamily: 'var(--font-display)' }}>{kpi.value}</div>
            <div className={`kpi-delta ${kpi.trend === 'up' ? 'delta-up' : kpi.trend === 'dn' ? 'delta-dn' : ''}`}
              style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              {kpi.trend === 'up' && <IconArrowUp size={12} />}
              {kpi.delta}
            </div>
          </div>
        ))}
      </div>

      {/* ── Charts Row ── */}
      <div className="two-col">
        {/* Donut Pie */}
        <div className="card">
          <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>Regional Customer Share</div>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={data.regionDistribution} cx="50%" cy="50%" innerRadius={75} outerRadius={115} paddingAngle={5} dataKey="value">
                {data.regionDistribution.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
              </Pie>
              <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 30px rgba(0,0,0,0.08)', fontFamily: 'var(--font-sans)' }} />
              <Legend iconType="circle" wrapperStyle={{ fontFamily: 'var(--font-sans)', fontSize: '13px' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Multi-Line Growth Chart */}
        <div className="card">
          <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>Customer Growth by Region</div>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={data.monthlyGrowth} margin={{ top: 5, right: 20, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="4 4" vertical={false} stroke="var(--color-border-primary)" />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: 'var(--color-text-muted)', fontFamily: 'var(--font-sans)' }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 12, fill: 'var(--color-text-muted)', fontFamily: 'var(--font-sans)' }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 30px rgba(0,0,0,0.08)', fontFamily: 'var(--font-sans)' }} />
              <Legend iconType="circle" wrapperStyle={{ fontFamily: 'var(--font-sans)', fontSize: '13px' }} />
              <Line type="monotone" dataKey="USA" stroke="#FF1300" strokeWidth={2.5} dot={false} />
              <Line type="monotone" dataKey="SEA" stroke="#fd6533" strokeWidth={2.5} dot={false} />
              <Line type="monotone" dataKey="India" stroke="#8c2800" strokeWidth={2.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ── Region Table ── */}
      <div className="card">
        <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>Region Breakdown</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1.8fr 1fr 1fr 1fr 1fr 1fr', gap: '8px', fontSize: '11px', fontWeight: 700, color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.8px', paddingBottom: '12px', borderBottom: '1px solid var(--color-border-primary)' }}>
          {['Region', 'Customers', 'Active', 'Paying', 'Revenue', 'Growth'].map(h => <span key={h}>{h}</span>)}
        </div>
        {data.regions.map((row, idx) => (
          <div key={idx} style={{ display: 'grid', gridTemplateColumns: '1.8fr 1fr 1fr 1fr 1fr 1fr', gap: '8px', padding: '14px 0', borderBottom: idx < data.regions.length - 1 ? '1px dashed var(--color-border-primary)' : 'none', alignItems: 'center', fontSize: '14px' }}>
            <div style={{ fontWeight: 700, color: 'var(--color-text-primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: '20px' }}>{row.flag}</span>{row.name}
            </div>
            <div style={{ fontWeight: 600, color: 'var(--color-text-secondary)' }}>{row.customers}</div>
            <div style={{ fontWeight: 600, color: 'var(--color-text-secondary)' }}>{row.active}</div>
            <div style={{ fontWeight: 600, color: 'var(--color-text-secondary)' }}>{row.paying}</div>
            <div style={{ fontWeight: 800, color: 'var(--color-text-primary)' }}>{row.revenue}</div>
            <div style={{ fontWeight: 700, color: 'var(--color-text-success)', display: 'flex', alignItems: 'center', gap: '4px' }}>
              <IconArrowUp size={13} />{row.growth || '--'}
            </div>
          </div>
        ))}
      </div>

      {/* ── Plan drilldown ── */}
      <div className="card">
        <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>USA → Plan Drilldown</div>
        <div className="three-col">
          {data.drilldown.map((item, idx) => (
            <div key={idx} style={{ background: 'var(--color-background-app)', borderRadius: 'var(--border-radius-lg)', padding: '20px', border: '1px solid var(--color-border-primary)', display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.8px' }}>{item.plan}</div>
              <div style={{ fontSize: '30px', fontWeight: 800, color: 'var(--color-text-primary)', fontFamily: 'var(--font-display)' }}>{item.count}</div>
              {/* mini progress bar */}
              <div style={{ background: 'var(--color-border-primary)', borderRadius: '4px', height: '6px', overflow: 'hidden' }}>
                <div style={{ width: `${item.percentage}%`, height: '100%', background: item.color, borderRadius: '4px', transition: 'width 1s ease' }} />
              </div>
              <div style={{ fontSize: '12px', fontWeight: 700, color: item.color }}>{item.percentage}% adoption</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Geography;
