import React, { useEffect, useState } from 'react';
import axios from 'axios';

// ── helpers ───────────────────────────────────────────────────────────────────
const PLAN_COLORS = {
  'Premier':      { bar: '#FF1300', badge: '#fff1f0', text: '#FF1300', border: '#ffccc7' },
  'Ultimate':     { bar: '#530F00', badge: '#fef2f2', text: '#7c1a0e', border: '#fca5a5' },
  'Essential':    { bar: '#fd6533', badge: '#fff7ed', text: '#c2410c', border: '#fed7aa' },
  'Essentials':   { bar: '#fd6533', badge: '#fff7ed', text: '#c2410c', border: '#fed7aa' },
  'Premier plus': { bar: '#8c2800', badge: '#fef2f2', text: '#991b1b', border: '#fca5a5' },
  'FreeTrial':    { bar: '#94a3b8', badge: '#f8fafc', text: '#475569', border: '#e2e8f0' },
  '5':            { bar: '#0369a1', badge: '#f0f9ff', text: '#0369a1', border: '#bae6fd' },
  'Unknown':      { bar: '#94a3b8', badge: '#f8fafc', text: '#64748b', border: '#e2e8f0' },
};
const planColor = (name) => PLAN_COLORS[name] || PLAN_COLORS['Unknown'];

const ProgressBar = ({ pct, color }) => (
  <div style={{ flex: 1, background: '#f1f5f9', borderRadius: 4, height: 8, overflow: 'hidden' }}>
    <div style={{ width: `${Math.min(pct, 100)}%`, height: '100%', background: color, borderRadius: 4, transition: 'width 0.6s ease' }} />
  </div>
);

const Badge = ({ label, plan }) => {
  const c = planColor(plan || label);
  return (
    <span style={{
      display: 'inline-block', padding: '2px 9px', borderRadius: 12,
      fontSize: 10, fontWeight: 600, letterSpacing: '0.3px',
      background: c.badge, color: c.text, border: `1px solid ${c.border}`,
    }}>{label}</span>
  );
};

const KpiCard = ({ label, value, sub, subColor }) => (
  <div className="kpi-card">
    <div className="kpi-label">{label}</div>
    <div className="kpi-value">{value ?? '…'}</div>
    {sub && <div className="kpi-delta" style={subColor ? { color: subColor } : {}}>{sub}</div>}
  </div>
);

// ── data fetcher ──────────────────────────────────────────────────────────────
async function fetchPlanData() {
  const [onboardRes, versiumRes] = await Promise.all([
    axios.get('/api/campstats/AccountOnboard/Get_OnBoardInfoAPI'),
    axios.get('/api/campstats/VersiumReach/Get_VersiumReachDetails'),
  ]);

  const onboardRaw = Array.isArray(onboardRes.data) ? onboardRes.data : [];
  const versiumRaw = Array.isArray(versiumRes.data) ? versiumRes.data : [];

  // Apply same filters as overview: empty Partner + exclude DXACC01
  const directOnboard = onboardRaw.filter(
    x => (!x.Partner || String(x.Partner).trim() === '') &&
         String(x.DiscountCode).trim() !== 'DXACC01'
  );

  // ── OnBoard plan breakdown ─────────────────────────────────
  const obTotal = directOnboard.length;
  const obTrials = directOnboard.filter(x => String(x.SubscribtionType).toLowerCase() === 'freetrial').length;
  const obPaying = obTotal - obTrials;

  const obPlans = directOnboard.reduce((acc, x) => {
    const p = x.SubscribtionType || 'Unknown';
    acc[p] = (acc[p] || 0) + 1;
    return acc;
  }, {});

  const onboardPlanRows = Object.entries(obPlans)
    .map(([name, count]) => ({ name, count, pct: Math.round((count / obTotal) * 100) }))
    .sort((a, b) => b.count - a.count);

  // ── Versium plan breakdown ─────────────────────────────────
  const vTotal = versiumRaw.length;
  const vTrials = versiumRaw.filter(x => String(x.LicenseTypeId).toLowerCase() === 'freetrial').length;
  const vPaying = vTotal - vTrials;

  const vPlans = versiumRaw.reduce((acc, x) => {
    const p = x.LicenseTypeId || 'Unknown';
    acc[p] = (acc[p] || 0) + 1;
    return acc;
  }, {});

  const versiumPlanRows = Object.entries(vPlans)
    .map(([name, count]) => ({ name, count, pct: Math.round((count / vTotal) * 100) }))
    .sort((a, b) => b.count - a.count);

  // ── Combined across both sources ───────────────────────────
  const combined = {};
  onboardPlanRows.forEach(r => { combined[r.name] = (combined[r.name] || 0) + r.count; });
  versiumPlanRows.forEach(r => { combined[r.name] = (combined[r.name] || 0) + r.count; });
  const grandTotal = obTotal + vTotal;
  const combinedRows = Object.entries(combined)
    .map(([name, count]) => ({ name, count, pct: Math.round((count / grandTotal) * 100) }))
    .sort((a, b) => b.count - a.count);

  return {
    onboard:  { total: obTotal, paying: obPaying, trials: obTrials, plans: onboardPlanRows },
    versium:  { total: vTotal,  paying: vPaying,  trials: vTrials,  plans: versiumPlanRows },
    combined: { total: grandTotal, paying: obPaying + vPaying, trials: obTrials + vTrials, plans: combinedRows },
  };
}

// ── default empty structure ──────────────────────────────────────────────────
const EMPTY_DATA = {
  onboard:  { total: 0, paying: 0, trials: 0, plans: [] },
  versium:  { total: 0, paying: 0, trials: 0, plans: [] },
  combined: { total: 0, paying: 0, trials: 0, plans: [] },
};

// ── Plan row component ────────────────────────────────────────────────────────
const PlanRow = ({ name, count, pct, total }) => {
  const c = planColor(name);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 0', borderBottom: '0.5px solid var(--color-border-tertiary)' }}>
      <div style={{ width: 100, flexShrink: 0 }}>
        <Badge label={name} plan={name} />
      </div>
      <ProgressBar pct={pct} color={c.bar} />
      <div style={{ width: 44, textAlign: 'right', fontSize: 12, fontWeight: 700, color: c.text, flexShrink: 0 }}>{count.toLocaleString()}</div>
      <div style={{ width: 36, textAlign: 'right', fontSize: 11, color: 'var(--color-text-tertiary)', flexShrink: 0 }}>{pct}%</div>
    </div>
  );
};

// ── Source toggle ─────────────────────────────────────────────────────────────
const Tab = ({ label, active, onClick }) => (
  <button onClick={onClick} style={{
    padding: '5px 14px', fontSize: 11, borderRadius: 16, border: 'none', cursor: 'pointer', fontWeight: 600,
    background: active ? '#FF1300' : 'transparent',
    color: active ? '#fff' : 'var(--color-text-tertiary)',
    transition: 'all 0.2s',
  }}>{label}</button>
);

// ── Main Plans Page ───────────────────────────────────────────────────────────
const Plans = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [source, setSource] = useState('onboard'); // 'onboard' | 'versium' | 'combined'

  useEffect(() => {
    fetchPlanData()
      .then(setData)
      .catch((err) => {
        console.warn('Failed to load live plan data:', err);
        setData(EMPTY_DATA);
      })
      .finally(() => setLoading(false));
  }, []);

  const d = data || EMPTY_DATA;
  const src = d[source] || { total: 0, paying: 0, trials: 0, plans: [] };
  const topPlan = src.plans?.[0];
  const trialPlan = src.plans?.find(p => p.name.toLowerCase() === 'freetrial');

  return (
    <div className="content">
      <div className="section-label">Plan Intel</div>

      {/* Source tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 16, background: 'var(--color-bg-secondary)', padding: 4, borderRadius: 20, width: 'fit-content', border: '0.5px solid var(--color-border-secondary)' }}>
        <Tab label="Direct (OnBoard)" active={source === 'onboard'} onClick={() => setSource('onboard')} />
        <Tab label="Versium" active={source === 'versium'} onClick={() => setSource('versium')} />
        <Tab label="Combined" active={source === 'combined'} onClick={() => setSource('combined')} />
      </div>

      {/* KPI Cards */}
      <div className="kpi-row">
        <KpiCard
          label="Total Accounts"
          value={loading ? '…' : src.total?.toLocaleString()}
          sub={source === 'onboard' ? 'Direct onboard' : source === 'versium' ? 'Versium partner' : 'OnBoard + Versium'}
        />
        <KpiCard
          label="Paying Accounts"
          value={loading ? '…' : src.paying?.toLocaleString()}
          sub={`${src.total ? Math.round((src.paying / src.total) * 100) : 0}% of total`}
          subColor="#059669"
        />
        <KpiCard
          label="Free Trial"
          value={loading ? '…' : src.trials?.toLocaleString()}
          sub={`${src.total ? Math.round((src.trials / src.total) * 100) : 0}% of total`}
        />
        <KpiCard
          label="Top Plan"
          value={loading ? '…' : topPlan?.name ?? '—'}
          sub={topPlan ? `${topPlan.pct}% of accounts` : ''}
        />
      </div>

      {/* Two columns */}
      <div className="two-col">

        {/* Plan Distribution */}
        <div className="card">
          <div className="card-title" style={{ marginBottom: 12 }}>
            Plan Distribution
            <span style={{ marginLeft: 8, fontSize: 10, fontWeight: 400, color: 'var(--color-text-tertiary)' }}>
              {src.total?.toLocaleString()} accounts
            </span>
          </div>
          {loading ? (
            <div style={{ padding: '20px 0', textAlign: 'center', color: 'var(--color-text-tertiary)', fontSize: 13 }}>Loading…</div>
          ) : (
            src.plans?.map(p => (
              <PlanRow key={p.name} name={p.name} count={p.count} pct={p.pct} total={src.total} />
            ))
          )}
        </div>

        {/* Plan Breakdown Summary */}
        <div className="card">
          <div className="card-title" style={{ marginBottom: 12 }}>Plan Breakdown Summary</div>

          {/* Paying vs Trial */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--color-text-secondary)', marginBottom: 8 }}>PAYING vs FREE TRIAL</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ width: 80, fontSize: 11, color: 'var(--color-text-secondary)', flexShrink: 0 }}>Paying</div>
                <ProgressBar pct={src.total ? Math.round((src.paying / src.total) * 100) : 0} color="#059669" />
                <div style={{ width: 50, textAlign: 'right', fontSize: 12, fontWeight: 700, color: '#059669', flexShrink: 0 }}>
                  {src.paying?.toLocaleString()}
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ width: 80, fontSize: 11, color: 'var(--color-text-secondary)', flexShrink: 0 }}>Free Trial</div>
                <ProgressBar pct={src.total ? Math.round((src.trials / src.total) * 100) : 0} color="#94a3b8" />
                <div style={{ width: 50, textAlign: 'right', fontSize: 12, fontWeight: 700, color: '#64748b', flexShrink: 0 }}>
                  {src.trials?.toLocaleString()}
                </div>
              </div>
            </div>
          </div>

          {/* Per-plan summary table */}
          <div>
            <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--color-text-secondary)', marginBottom: 8 }}>PER-PLAN DETAILS</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 60px 60px 50px', gap: 4, fontSize: 10, color: 'var(--color-text-tertiary)', paddingBottom: 6, borderBottom: '0.5px solid var(--color-border-secondary)', marginBottom: 4 }}>
              <span>Plan</span>
              <span style={{ textAlign: 'right' }}>Accounts</span>
              <span style={{ textAlign: 'right' }}>Share</span>
              <span style={{ textAlign: 'right' }}>Status</span>
            </div>
            {src.plans?.map(p => {
              const c = planColor(p.name);
              const isTrial = p.name.toLowerCase() === 'freetrial';
              return (
                <div key={p.name} style={{ display: 'grid', gridTemplateColumns: '1fr 60px 60px 50px', gap: 4, padding: '5px 0', borderBottom: '0.5px solid var(--color-border-tertiary)', alignItems: 'center' }}>
                  <Badge label={p.name} plan={p.name} />
                  <div style={{ textAlign: 'right', fontSize: 12, fontWeight: 700 }}>{p.count.toLocaleString()}</div>
                  <div style={{ textAlign: 'right', fontSize: 11, color: 'var(--color-text-tertiary)' }}>{p.pct}%</div>
                  <div style={{ textAlign: 'right' }}>
                    <span style={{ fontSize: 10, fontWeight: 600, color: isTrial ? '#64748b' : '#059669' }}>
                      {isTrial ? 'Trial' : 'Paid'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Plans;
