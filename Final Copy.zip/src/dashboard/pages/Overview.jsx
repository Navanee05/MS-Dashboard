import React, { useState, useEffect } from 'react';
import { getOverviewData } from '../../api/dashboardApi';
import { IconLoader2, IconUsers, IconCreditCard, IconTrendingUp, IconCurrencyDollar, IconArrowUp, IconArrowDown } from '@tabler/icons-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';

const iconMap = {
  users: IconUsers,
  'credit-card': IconCreditCard,
  'trending-up': IconTrendingUp,
  dollar: IconCurrencyDollar,
};

const Overview = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try { setData(await getOverviewData()); }
      catch (e) { console.error(e); }
      finally { setLoading(false); }
    })();
  }, []);

  if (loading || !data) return (
    <div className="content loading-skeleton">
      <IconLoader2 size={40} /><p>Loading Portfolio...</p>
    </div>
  );

  return (
    <div className="content">
      {/* ── Page Header ── */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div className="section-label">Portfolio Overview</div>
          <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginTop: '4px' }}>
            Real-time customer intelligence across all channels
          </p>
        </div>
        <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--color-text-muted)', background: 'var(--color-background-primary)', border: '1px solid var(--color-border-primary)', padding: '8px 16px', borderRadius: '10px' }}>
          Last updated: Jun 2025
        </div>
      </div>

      {/* ── KPI Row ── */}
      <div className="kpi-row">
        {data.kpis.map((kpi, idx) => {
          const Icon = iconMap[kpi.icon] || IconUsers;
          return (
            <div className="kpi-card" key={idx} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div className="kpi-label">{kpi.label}</div>
                <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: kpi.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Icon size={18} color={kpi.iconColor} stroke={2} />
                </div>
              </div>
              <div className="kpi-value" style={{ fontFamily: 'var(--font-display)' }}>{kpi.value}</div>
              <div className={`kpi-delta ${kpi.trend === 'up' ? 'delta-up' : kpi.trend === 'dn' ? 'delta-dn' : ''}`}
                style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                {kpi.trend === 'up' && <IconArrowUp size={12} stroke={2.5} />}
                {kpi.trend === 'dn' && <IconArrowDown size={12} stroke={2.5} />}
                {kpi.delta}
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Charts Row ── */}
      <div className="two-col">
        {/* Area Chart */}
        <div className="card">
          <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>
            Customer & MRR Growth
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={data.acquisitionChart} margin={{ top: 5, right: 20, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="gMrr" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#FF1300" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#FF1300" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gCust" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8c2800" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#8c2800" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="4 4" vertical={false} stroke="var(--color-border-primary)" />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: 'var(--color-text-muted)', fontFamily: 'var(--font-sans)' }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 12, fill: 'var(--color-text-muted)', fontFamily: 'var(--font-sans)' }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 30px rgba(0,0,0,0.08)', fontFamily: 'var(--font-sans)' }} />
              <Area type="monotone" dataKey="mrr" name="MRR ($K)" stroke="#FF1300" strokeWidth={2.5} fill="url(#gMrr)" dot={false} />
              <Area type="monotone" dataKey="customers" name="Customers" stroke="#8c2800" strokeWidth={2.5} fill="url(#gCust)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Channel Mix Donut */}
        <div className="card">
          <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>Channel Mix</div>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={data.channelMix} cx="50%" cy="50%" innerRadius={70} outerRadius={105} paddingAngle={4} dataKey="value">
                {data.channelMix.map((entry, i) => (
                  <Cell key={i} fill={entry.fill || entry.color || ['#FF1300', '#FD6533', '#8C2800'][i % 3]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 30px rgba(0,0,0,0.08)', fontFamily: 'var(--font-sans)' }} />
              <Legend iconType="circle" wrapperStyle={{ fontFamily: 'var(--font-sans)', fontSize: '13px' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ── Funnel + Addons ── */}
      <div className="two-col">
        <div className="card">
          <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>Activation Funnel</div>
          {data.funnel.map((step, idx) => (
            <div className="funnel-step" key={idx}>
              <div className="funnel-label">{step.label}</div>
              <div className="funnel-bar-wrap">
                <div className="funnel-bar" style={{ width: `${step.percentage}%`, background: step.color }}>
                  <span className="funnel-num">{step.value}</span>
                </div>
              </div>
              <div className="funnel-pct">{step.percentage}%</div>
            </div>
          ))}
        </div>

        <div className="card">
          <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>Add-On Adoption</div>
          {data.addOns.map((f, idx) => (
            <div key={idx} className="feat-row">
              <div className="feat-name">{f.name}</div>
              <div className="feat-bar-wrap">
                <div className="feat-bar-fill" style={{ width: `${f.percentage}%`, background: f.color }} />
              </div>
              <div className="feat-pct">{f.percentage}%</div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Health Summary ── */}
      <div className="card">
        <div className="card-title" style={{ fontFamily: 'var(--font-display)' }}>Customer Health Summary</div>
        {data.healthSummary.rows.map((row, idx) => (
          <div key={idx} className="health-row">
            <div className="health-dot" style={{ background: row.color }} />
            <div className="health-lbl">{row.label}</div>
            <div className="health-ct" style={{ color: row.textColor }}>{row.count}</div>
            <div className="health-bar-wrap">
              <div className="health-bar-fill" style={{ width: `${row.percentage}%`, background: row.color }} />
            </div>
            <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--color-text-muted)', width: '36px', textAlign: 'right' }}>
              {row.percentage}%
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Overview;
