import { cachedFetch } from '../utils/apiCache';

const BASE = '/api/campstats/VersiumReach';

// ── helpers ───────────────────────────────────────────────────────────────────
const safeFetch = (url) =>
  fetch(url)
    .then((r) => {
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return r.json();
    })
    .catch((err) => {
      console.warn(`[partnerService] fetch failed: ${url}`, err.message);
      return null;
    });

// ── shape builder ─────────────────────────────────────────────────────────────
function buildAccountShape(raw, enriched = {}) {
  const plan = raw.LicenseTypeId || raw.plan || 'Unknown';
  const isActive = plan !== '' && plan.toLowerCase() !== 'inactive';
  return {
    id: String(raw.ClientID || raw.id || raw.userId || ''),
    name: raw.Clientname || raw.name || '',
    email: raw.Emailname || raw.email || '',
    plan,
    partnerType: raw.PartnerType || raw.partnerType || 'Versium',
    createdDate: raw.CreatedDt || raw.createdDate || '',
    lastLogin: raw.LastLogInTime || raw.lastLogin || '',
    databasename: raw.Databasename || raw.databasename || '',
    isActive,
    campaigns: enriched.campaigns || [],
    campaignCount: (enriched.campaigns || []).length,
    totalSent: enriched.totalSent || 0,
    totalDelivered: enriched.totalDelivered || 0,
    totalOpened: enriched.totalOpened || 0,
    totalClicked: enriched.totalClicked || 0,
    deliveryRate: enriched.deliveryRate || 0,
    listsUploaded: enriched.listsUploaded || 0,
    templatesCreated: enriched.templatesCreated || 0,
    totalCommJobs: enriched.totalCommJobs || 0,
    completedJobs: enriched.completedJobs || 0,
    paidJobs: enriched.paidJobs || 0,
    hasUnpaid: enriched.hasUnpaid || false,
  };
}

// ── per-account enrichment ────────────────────────────────────────────────────
/**
 * Fetches all 4 per-account APIs using the Databasename from Get_VersiumReachDetails.
 */
async function enrichVersiumAccount(account) {
  const db = account.Databasename || account.databasename;
  if (!db) return buildAccountShape(account);

  return cachedFetch(`versium_live_${db}`, async () => {
    const today = new Date();
    const toDate = new Date(today.getFullYear(), 11, 31).toISOString().split('T')[0];

    const [commList, audienceList, templateList, channelBreakdown] = await Promise.all([
      safeFetch(`${BASE}/GetCommunicationListDetailsAPI?&DatabaseName=${db}`),
      safeFetch(`${BASE}/GetAudiencelistDetailsAPI?Databasename=${db}&FromDate=2025-01-01&ToDate=${toDate}`),
      safeFetch(`${BASE}/GetTemplatelistDetailsAPI?Databasename=${db}`),
      safeFetch(`${BASE}/GetChannelwiseBreakdownDetailsAPI?Databasename=${db}&FromDate=2025-01-01&ToDate=${toDate}&ChannelType=1`),
    ]);

    const commJobs    = Array.isArray(commList)        ? commList        : [];
    const audiences   = Array.isArray(audienceList)    ? audienceList    : [];
    const templates   = Array.isArray(templateList)    ? templateList    : [];
    const campaigns   = Array.isArray(channelBreakdown)? channelBreakdown: [];

    const completedLists  = audiences.filter(a => String(a.StatusID).toLowerCase() === 'completed');
    const activeTemplates = templates.filter(t => String(t.StatusID).toLowerCase() === 'active');

    let totalSent = 0, totalDelivered = 0, totalOpened = 0, totalClicked = 0;

    const campaignDetails = campaigns.map((c, idx) => {
      const sent      = Number(c.Sent      || 0);
      const delivered = Number(c.Delivered || 0);
      const opened    = Number(c.Opened    || 0);
      const clicked   = Number(c.Clicked   || 0);
      totalSent      += sent;
      totalDelivered += delivered;
      totalOpened    += opened;
      totalClicked   += clicked;

      const pname = c.Campaignname || c.CampaignName || c.Campaign || c.Name || '';
      return {
        id: `vc${idx + 1}`,
        name: pname || (c.CampaignType || 'Email') || `Campaign ${idx + 1}`,
        type: c.CampaignType || 'Email',
        sentOn: c.SentOn || '',
        sent,
        delivered,
        opened,
        clicked,
        deliveryRate: sent > 0 ? Math.round((delivered / sent) * 100) : 0,
        openRate: delivered > 0 ? Math.round((opened / delivered) * 100) : 0,
      };
    });

    const deliveryRate = totalSent > 0 ? Math.round((totalDelivered / totalSent) * 100) : 0;

    return buildAccountShape(account, {
      campaigns: campaignDetails,
      totalSent,
      totalDelivered,
      totalOpened,
      totalClicked,
      deliveryRate,
      listsUploaded:  completedLists.length,
      templatesCreated: activeTemplates.length,
      totalCommJobs: commJobs.length,
      completedJobs: commJobs.filter(j => String(j.statusID).toLowerCase() === 'completed').length,
      paidJobs:      commJobs.filter(j => String(j.IsPaymentDone).toLowerCase() === 'paid').length,
      hasUnpaid:     commJobs.some(j => String(j.IsPaymentDone).toLowerCase() === 'not paid'),
    });
  }, 10 * 1000);
}

// ── Public API ────────────────────────────────────────────────────────────────

/**
 * Fetch all Versium accounts directly from live API with automatic caching.
 */
export async function fetchVersiumAccounts() {
  return cachedFetch("all_versium_accounts", async () => {
    const raw = await safeFetch(`${BASE}/Get_VersiumReachDetails`);
    if (Array.isArray(raw) && raw.length > 0) {
      return raw.map(a => buildAccountShape(a));
    }
    return [];
  }, 10 * 1000);
}

/**
 * Fetch a single Versium account by ClientID, fully enriched with all 4 per-account APIs.
 */
export async function fetchVersiumAccountById(clientId) {
  const all = await fetchVersiumAccounts();
  if (Array.isArray(all) && all.length > 0) {
    const account = all.find(
      a => String(a.ClientID) === String(clientId) || String(a.id) === String(clientId) || String(a.userId) === String(clientId)
    );
    if (!account) throw new Error(`Versium account ${clientId} not found`);
    return enrichVersiumAccount(account);
  }
  throw new Error(`Versium account ${clientId} not found`);
}

/**
 * Fetch Versium partner KPIs — aggregated totals + plan distribution directly from live data.
 */
export async function fetchVersiumPartnerKpis() {
  return cachedFetch("versium_partner_kpis", async () => {
    const raw = await safeFetch(`${BASE}/Get_VersiumReachDetails`);

    if (Array.isArray(raw) && raw.length > 0) {
      const total  = raw.length;
      const active = raw.filter(a => a.LicenseTypeId && a.LicenseTypeId !== '').length;
      const plans  = raw.reduce((acc, a) => {
        const p = a.LicenseTypeId || 'Unknown';
        acc[p] = (acc[p] || 0) + 1;
        return acc;
      }, {});
      const planBreakdown = Object.entries(plans)
        .map(([name, count]) => ({ name, count, pct: Math.round((count / total) * 100) }))
        .sort((a, b) => b.count - a.count);

      return { total, active, inactive: total - active, planBreakdown };
    }

    return {
      total: 0,
      active: 0,
      inactive: 0,
      planBreakdown: [],
    };
  }, 10 * 1000);
}

